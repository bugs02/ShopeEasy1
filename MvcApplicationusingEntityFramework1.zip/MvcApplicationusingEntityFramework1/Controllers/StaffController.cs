﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplicationusingEntityFramework1.Models;
using System.Data.Entity;

namespace MvcApplicationusingEntityFramework1.Controllers
{
    public class StaffController : Controller
    {
        //
        // GET: /Staff/

        Training_18Jan2017_TalwadeEntities2 context = new Training_18Jan2017_TalwadeEntities2();

        public ActionResult Index()
        {
          
          return View(context.staff_master_121711);
        }

        public ActionResult Details(int id)
        {
            return View(context.staff_master_121711.Find(id));
        }

        public ActionResult CreateStaff()
        {
            return View();
        }

        [HttpPost]
        public ActionResult CreateStaff(staff_master_121711 staff)
        {
            if (ModelState.IsValid)
            {
                context.staff_master_121711.Add(staff);
                context.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                return View(staff);
            }
        }

      public ActionResult DeleteStaff()
      {
            return View();
        }

        [HttpPost]
        public ActionResult DeleteStaff(int id)
        {
            staff_master_121711 staff=new staff_master_121711();
            if (ModelState.IsValid)
            {
                staff=context.staff_master_121711.Find(id);
                context.staff_master_121711.Remove(staff);
                context.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                return View(staff);
            } 
        }

        public ActionResult UpdateStaff(int id)
        {
            return View(context.staff_master_121711.Find(id));
        }

        [HttpPost]
        public ActionResult UpdateStaff(staff_master_121711 sobj)
        {
            staff_master_121711 staff = new staff_master_121711();
            if (ModelState.IsValid)
            {
                staff = context.staff_master_121711.First(e=>e.Staff_Code==sobj.Staff_Code);
                staff.Staff_Name = sobj.Staff_Name;
                staff.Salary = sobj.Salary;
                staff.Mgr_Code = sobj.Mgr_Code;
                context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(staff);
        }
    }
}
